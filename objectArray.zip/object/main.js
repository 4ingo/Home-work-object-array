// 1
// У нас есть объект, в котором хранятся зарплаты нашей команды:
//Напишите код для суммирования всех зарплат и сохраните результат в переменной sum. Должно получиться 390.
// let salaries = {
//         John: 100,
//          Ann: 160,
//          Pete: 130
//     };
//  sum=salaries.John+salaries.Ann+salaries.Pete;
// console.log(salaries.John+" + "+salaries.Ann+" + "+salaries.Pete+" = "+sum);

// 2
// У вас есть объект {name:'Ivan', age: 26} в консоли вытащить значение ключа name
//  let object={
//     name:'Ivan',
//      age:26
// };
// console.log(object.name);

// 3
// У вас есть объект {name:'Ivan', age: 26} ключ age заменить на прошлое значение и + 5.

// let object={
//     name:'Ivan',
//     age: 26
// };
// console.log(object.age=26+5);

// 4
// У вас есть объект {name:'Ivan', age: 26, student: true}. Заменить значение ключа student на противоположный4
// let object={
//     name:'Ivan',
//     age: 26,
//     student: true
// }
// console.log(object.student=false);
// console.log(object);


// У вас есть объект {name:ABRACADABRA', age: 15, student: true}. Проверить что значение ключа name содержит в себе подстроку BRAC
// let object={name:'ABRACADABRA',
//         age: 15,
//     student: true};
// console.log(object.name.);

// 6
// У вас есть объект {name:'Ivan', age: 26, student: true}. В консоли вывести все варианты перевода объекта в массив
// let object={
//     name:'Ivan',
//     age: 26,
//     student: true
// };
// Object.keys(object);
// console.log(object);


// 8
// У вас есть массив cars = ['bmw', 'honda','mers','lexus'] удалить последний элемент
//
// let cars = ['bmw', 'honda','mers','lexus'];
// console.log(cars.pop());
// console.log(cars);

//9
// У вас есть массив cars = ['bmw', 'honda','mers','lexus']. Получить последний элемент
// let cars=cars = ['bmw', 'honda','mers','lexus'];
// console.log(cars.pop());

//10
// У вас есть массив cars = ['bmw', 'honda','mers','lexus']. Заменить второй элемент на 'toyota'
// let cars=['bmw', 'honda','mers','lexus'];
// let delate= cars.splice(1, 1, 'Toyota');
// console.log(cars);

//11
// У вас есть массив cars = ['bmw', 'honda','mers','lexus']. Добавить в начало новый элемент 'kia'
//
// let cars=['bmw', 'honda','mers','lexus'];
// cars[0]='kia';
// console.log(cars);

//12
//У вас есть массив cars = ['bmw', 'honda','mers','lexus']. В консоли получить длину этого массива

let cars=['bmw', 'honda','mers','lexus'];
console.log(cars.length);